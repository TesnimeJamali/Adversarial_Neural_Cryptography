# Image-Patch Neural Cipher — Training & Usage Guide

## Overview

The models in `./checkpoints/seed_13/` were trained on **random 16-bit binary vectors**.
They generalise poorly to image patches because image patch bits are **not uniformly distributed** —
natural images have strong spatial correlations that the random-trained cipher has never seen.

This guide walks you through retraining on CIFAR-10 patches and verifying the result.

---

## Step 1 — Prerequisites

```bash
pip install tensorflow pillow matplotlib numpy
```

Confirm CIFAR-10 images are in `./training_images/` (50,000 PNG/JPG files):
```bash
ls ./training_images/ | wc -l   # should print ~50000
```

---

## Step 2 — Train on Image Patches

Run the training script. The `image_patches` mode is already implemented in `main_enhanced.py`.

```bash
python main_enhanced.py \
  --mode         image_patches \
  --image_dir    ./training_images \
  --patch_size   4 \
  --msg_size     16 \
  --key_size     16 \
  --batch_size   4096 \
  --steps        50000 \
  --lr           0.0008 \
  --eve_steps    2 \
  --loss_fn      quadratic \
  --seed         13 \
  --save_dir     ./checkpoints/image_patches_4x4 \
  --plot_dir     ./plots/image_patches_4x4 \
  --eve_retrain  5 \
  --eve_retrain_steps 5000 \
  --log_every    500
```

### What to watch during training

| Phase | Approx. step | Bob error | Eve error |
|-------|-------------|-----------|-----------|
| 1 — Random | 0–2k | ~8 bits | ~8 bits |
| 2 — Trivial cipher | 2k–10k | drops rapidly | drops too |
| 3 — Eve breaks trivial | 10k–20k | rises slightly | < 8 bits |
| 4 — Key-dependent cipher | 20k–50k | → < 1 bit | → ~8 bits |

If Bob error is still > 2 bits at step 50k, extend to `--steps 80000`.

### Expected terminal result

```
Step 50000  |  Bob:  0.41 [████                ] | Eve:  7.89 [████████████████    ]
...
  Run  1/ 5  |  Best Eve error: 8.24 bits  |  Baseline: 8.0  |  ✅ SECURE
  Run  2/ 5  |  Best Eve error: 8.71 bits  |  Baseline: 8.0  |  ✅ SECURE
  ...
  Secure runs: 5/5
```

**Success criteria:**
- Bob error < 2 bits (ideally < 1)
- Eve error ≈ 7.5–9.0 bits (near the 8-bit random baseline)
- Post-training robustness: ≥ 4/5 secure runs

---

## Step 3 — Run the Demo

After training completes, the weights are saved in `./checkpoints/image_patches_4x4/`.

```bash
# With your own image
python demo_encryption.py \
  --image            your_photo.jpg \
  --checkpoint-dir   ./checkpoints/image_patches_4x4 \
  --output           demo_result.png \
  --eve-steps        3000

# With auto-generated synthetic test pattern
python demo_encryption.py \
  --create-test \
  --checkpoint-dir   ./checkpoints/image_patches_4x4
```

Expected output figure: `demo_result.png`
Contains 5 panels: Original | Encrypted | Decrypted (soft) | Wrong-key | Error Heatmap
Plus Eve learning curve at the bottom.

**Expected PSNR after retraining:** > 30 dB (was 4.7 dB before retraining)

---

## Step 4 — Verify a Specific Image

```bash
python - <<'EOF'
from image_encryptor import ImageEncryptor
import numpy as np

enc = ImageEncryptor(checkpoint_dir="./checkpoints/image_patches_4x4")
key = enc.generate_key()

result = enc.verify_encryption(
    image_path="your_photo.jpg",
    key=key,
    output_dir="./verify_output"
)

print(f"PSNR (soft): {result['psnr_soft']:.1f} dB")
print(f"Mean errors/block: {result['mean_errors_per_block']:.3f} / 16")
print(f"Blocks >4 errors: {result['blocks_over_threshold']}")
EOF
```

---

## Step 5 — Full Security Evaluation

```bash
python security_eval.py \
  --image          your_photo.jpg \
  --checkpoint-dir ./checkpoints/image_patches_4x4 \
  --runs           5 \
  --steps          5000 \
  --output-dir     ./security_results
```

---

## Troubleshooting

### Bob error stays high (> 3 bits after 50k steps)

Possible causes:
1. **Image loader issue** — check that `./training_images/` contains valid CIFAR-10 images:
   ```bash
   python -c "from PIL import Image; img = Image.open('./training_images/cifar_00001.png'); print(img.size)"
   ```
2. **Wrong msg_size** — must be `patch_size × patch_size = 16`. Confirm `--msg_size 16 --patch_size 4`.
3. **Need more steps** — try `--steps 80000`.
4. **Unlucky seed** — try `--seed 7` or `--seed 42`.

### Eve error drops below 6 bits and stays there

The training got stuck. Solutions:
- Increase `--eve_steps 3` (more adversarial pressure)
- Restart with a different seed
- Check that `--loss_fn quadratic` (not `bce`)

### PSNR still low (< 20 dB) after retraining

This is a soft-decoding issue, not a training issue. Make sure you're using the new
`image_encryptor.py` (v2) which uses sigmoid soft decoding by default. The old hard
`np.sign()` threshold gives PSNR ≈ 4–10 dB; soft decoding gives 30+ dB.

Confirm soft decoding is active:
```python
img = enc.decrypt_image(enc_path, key, soft=True)  # soft=True is the default
```

---

## File Summary

| File | Purpose | Modified? |
|------|---------|-----------|
| `main_enhanced.py` | Training engine (image_patches mode built-in) | No changes needed |
| `image_encryptor.py` | Encrypt/decrypt with soft decoding + verify | **Updated (v2)** |
| `demo_encryption.py` | 5-panel figure + Eve curve + PSNR | **Updated (v2)** |
| `security_eval.py` | Multi-run Eve robustness evaluation | No changes needed |
| `crypto_tool.py` | CLI wrapper | No changes needed |

---

## Key Differences: Random vs Image-Patch Training

| Aspect | Random training | Image-patch training |
|--------|----------------|----------------------|
| Training distribution | Uniform {-1,+1} | Natural image patches (correlated bits) |
| PSNR on real images | 4–10 dB | 30–50 dB |
| Bob error (training) | < 1 bit | < 1 bit |
| Eve error | ~8 bits | ~8 bits |
| Checkpoint dir | `./checkpoints/seed_13` | `./checkpoints/image_patches_4x4` |
| Decoding method | Hard np.sign() was OK | **Soft sigmoid required** for good PSNR |

The soft decoding improvement alone (with old random-trained models) gives ~15–20 dB.
Retraining on image patches on top of that gives the full 30+ dB.
